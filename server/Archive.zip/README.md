To build webpack
npx webpack --config webpack.config.js

npm run build

npm start

Todos
----------------------------------------
Router
Events, custom events from components
Enhanced grid/table
