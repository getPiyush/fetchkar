    //React
    import React from "react";
    import ReactDOM from "react-dom";
    import ReactApp from "./js/react/ReactApp.js";

export default function initApp(appbase) {

    console.log("app initiated with "+appbase);
    console.log("testing webpack server!");




if(appbase==="react"){
    ReactDOM.render(<ReactApp />, document.getElementById("reactLoader"));
}



}