import _ from 'lodash';

//Bootstrap
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import 'popper.js/dist/popper.min.js'
import 'jquery/dist/jquery.slim.js';


import './css/style.css';
import './css/sticky-footer-navbar.css';
//import siteLogo from './logo.png';





import initApp from './init.js';

const appBase = "react"; //react/angular


function component() {
    let element = document.createElement('pre');
  
    // Lodash, currently included via a script, is required for this line to work
    element.innerHTML = _;//.join(['Hello', 'webpack'], ' ');
  /*
    let headerLogo = document.getElementById("nfLogoHeader");
    headerLogo.src = siteLogo;

    let footerLogo = document.getElementById("nfLogoFooter");
    footerLogo.src = siteLogo;
*/
    initApp(appBase);


    return element;
  }
  
  document.body.appendChild(component());