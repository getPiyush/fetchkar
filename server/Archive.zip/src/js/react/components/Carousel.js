import React, { Component} from "react";

class Carousel extends Component{
    constructor(props) {
        super(props);
      }

    render(){
        let carouselIndicators = [];
        let carouselInner = [];
        //console.log(undefined!==this.props.data && Array.isArray(this.props.data));
        if(undefined!==this.props.data && Array.isArray(this.props.data)){
            this.props.data.forEach((element,index) => {
                let active = index===0?"active":"";

                carouselIndicators.push(<li data-target="#carouselExampleIndicators" data-slide-to={index} key={index} className={active}></li>);
                

                carouselInner.push(
                    <div className={"carousel-item "+active+" embed-responsive-4by3"} key={index}>
                        <img src={element} className="img-fluid  mx-auto d-block"></img>
                    </div>
                );
            
            });

        }
       
      return(
        <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel">
            <ol className="carousel-indicators">
                {carouselIndicators}
            </ol>
            <div className="carousel-inner">
                {carouselInner}
            </div>
            <a className="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="sr-only">Previous</span>
            </a>
            <a className="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="sr-only">Next</span>
            </a>
      </div>

      );
    }
  }
  
  export default Carousel;