
import React, { Component } from "react";


class Table extends Component {

    

    render() {
        if(this.props.data){
            //const renderers = this.props.data.renderers;
            let header = this.generateColumn(this.props.data.headers, "col");
            let body = this.generateRows(this.props.data.rows);
            let theme = "table "+this.props.data.theme;
            

            return (
                <div>
                <table className={theme}>
                    <thead>
                        {header}
                    </thead>
                    {body}
                </table>
                
                </div>
            )
        }
        else{
            return(
                <div className="alert alert-warning" role="alert">
                No Data Defined!, please define data.
                </div>
            )
        }

    }

    generateColumn(headers, type, key) {
        let headerComp = [];
        let rendererComp = null;
        let renderers = this.props.data.renderers;
        headers.forEach((element, index) => {
            if(renderers && renderers[index] != null)
            {
                rendererComp = React.cloneElement(
                    renderers[index],
                    {data: element}
                  )
                //renderers[index].props.data = element;
                //console.log(renderers[index]);
            }
            else{
                rendererComp = element;
            }
             

            if (type === "row") {

                if (index === 0 && this.props.data.firstColumnBold) {
                    headerComp.push(<th key={index + "th"} scope="row" >{rendererComp}</th>);
                } else {
                    headerComp.push(<td key={index + "td"}>{rendererComp}</td>);
                }


            }
            else {
                headerComp.push(<th key={index + "th"} scope="col" >{element}</th>);
            }


        });

        return (<tr key={key + "tr"}>{headerComp}</tr>);

    }

    generateRows(rows) {
        let rowComp = [];
        rows.forEach((element, index) => {
            let rowElement = this.generateColumn(element, "row", index);
            rowComp.push(rowElement);

        });

        return (<tbody>{rowComp}</tbody>);

    }
}

export default Table;



