
import React, { Component} from "react";


class Jumbotorn extends Component{
  render(){
    return(
    <div className="jumbotron jumbotron-fluid">
        <div className="container">
            <h1 className="display-4">{this.props.data.headerText}</h1>
            <p className="lead">{this.props.data.content}</p>
        </div>
        </div>
    );
  }
}

export default Jumbotorn;



