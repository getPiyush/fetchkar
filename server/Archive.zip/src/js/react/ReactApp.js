import React, { Component} from "react";
import Jumbotorn from "./components/Jumbotorn";
import Table from "./components/Table";
import Carousel from "./components/Carousel";
//import { ProgressPlugin } from "webpack";
import TextRenderer from "./TextRenderer";

const carouselData = ["assets/images/img2.jpg",
                      "assets/images/img3.jpg",
                      "assets/images/img4.jpg",
                      "assets/images/logo.png"];

//<!-- <Carousel data={carouselData}/> -->

const jumbotronData = {
  headerText:"This is a React Header!",
  content:"Yuo can add anything in this content,as jumbotron content, Just like I am adding so many things"
};
const textRenderer = <TextRenderer/>;

const tableData = {
  theme:"table-striped table-bordered", //table-dark, table-striped, table-bordered, table-sm .. support all bootstrap themes
  firstColumnBold:true,
  headers:["#","First Name","Middle Name","Last Name","Age","Role"],
  rows:[[1,"Piyush","Plaban","Praharaj",12,"Artichoke"],
        [2,"Piyush","Plaban","Praharaj",54,"Artichoke"],
        [3,"Piyush","Plaban","Praharaj//",25,"Artichoke"],
        [4,"Piyush","Plaban","Praharaj",32,"Artichoke"]
      ],
  renderers:[null,null,null,null,textRenderer,textRenderer]
}

class ReactApp extends Component{
  render(){
    return(
      <div className="row">
       
        <Jumbotorn data={jumbotronData}/>
        <Table data={tableData}/>
        
      </div>

    );
  }
}


export default ReactApp;