import React, { Component } from "react";
import { isNumber } from "util";

class TextRenderer extends Component {
  constructor(props) {
    super(props);
    this.colorclass = ["Primary", "Secondary", "Success", "Danger", "Warning", "Info", "Light", "Dark"];
    this.code = "badge badge-light";
  }

  render() {
    if (isNumber(this.props.data)) {
      this.code =  "badge badge-" + this.colorclass[this.getRandomInt(0, this.colorclass.length-1)].toLowerCase();
    }

    return (
      <span className={this.code}>{this.props.data}</span>
    );
  }

  getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

export default TextRenderer;