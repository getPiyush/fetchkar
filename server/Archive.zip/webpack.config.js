const path = require('path');
const webpack = require("webpack");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const imageminMozjpeg = require('imagemin-mozjpeg');
const ImageminPlugin = require('imagemin-webpack-plugin').default;




module.exports = {
    mode: 'development',

    entry: {
        webpack: './src/index.js',
        app: './src/init.js'
    },
    devtool: 'inline-source-map',
    devServer: {
        contentBase: './dist'
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: './src/index.html',
            title: 'Nectflow',
            mobile: true,
            lang: 'en-US',
            baseHref: 'http://www.nectflow.com',
            devServer: 'http://localhost:3000',
            links: [
                {
                    href: 'assets/images/favicon.png',
                    rel: 'icon',
                    sizes: '32x32',
                    type: 'image/png'
                }
            ]

        }),

        new CopyWebpackPlugin([
            { from: 'src/assets', to: 'assets' }
        ]),
        new ImageminPlugin({
            pngquant: ({ quality: '50' }),
            plugins: [imageminMozjpeg({ quality: '50' })]
        }),
        new webpack.HotModuleReplacementPlugin()
    ],

    resolve: { extensions: ["*", ".js", ".jsx"] },
    output: {
        filename: '[name].bundle.js',
        path: path.resolve(__dirname, 'dist')
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /(node_modules|bower_components)/,
                loader: "babel-loader",
                options: { presets: ["@babel/env"] }
              },
            {
                test: /\.css$/,
                use: [
                    'style-loader',
                    'css-loader'
                ]
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use: [
                    'file-loader'
                ]
            },
            {
                test: /\.(woff|woff2|eot|ttf|otf)$/,
                use: [
                    'file-loader'
                ]
            }
        ]
    }
};